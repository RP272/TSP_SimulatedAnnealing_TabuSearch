#ifndef INPUTDATA_H
#define INPUTDATA_H

struct InputData
{
	int numberOfCities;
	int** costMatrix;
};

#endif